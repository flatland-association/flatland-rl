# -*- coding: utf-8 -*-

"""Top-level package for flatland."""

__author__ = """S.P. Mohanty"""
__email__ = 'mohanty@aicrowd.com'
__version__ = '3.0.8'
