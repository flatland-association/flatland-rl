# Credits

Development
-----------

* Christian Baumberger <christian.baumberger@sbb.ch>
* Christian Eichenberger <christian.markus.eichenberger@sbb.ch>
* Adrian Egli <adrian.egli@sbb.ch>
* Mattias Ljungström
* Sharada Mohanty <mohanty@aicrowd.com>
* Guillaume Mollard <guillaume.mollard2@gmail.com>
* Erik Nygren <erik.nygren@sbb.ch>
* Giacomo Spigler <giacomo.spigler@gmail.com>
* Jeremy Watson


Acknowledgements
----------------
* Vaibhav Agrawal <theinfamouswayne@gmail.com>
* Anurag Ghosh


Contributors
------------

None yet. Why not be the first?
